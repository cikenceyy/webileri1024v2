<?php

namespace App\Http\Controllers;

class UIController extends Controller
{
    public function index()
    {
        return view('ui.index');
    }
}

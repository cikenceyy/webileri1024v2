<?php

use Illuminate\Support\Facades\Route;

// Console routes placeholder. Example:
// Route::middleware(['web','auth'])->prefix('console')->group(function () {
//     Route::get('/', fn() => view('console::dashboard'))->name('console.dashboard');
// });

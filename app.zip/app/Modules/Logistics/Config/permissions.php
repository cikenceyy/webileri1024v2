<?php

return [
    'logistics.shipment.view',
    'logistics.shipment.create',
    'logistics.shipment.update',
    'logistics.shipment.delete',
];

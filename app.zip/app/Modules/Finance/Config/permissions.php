<?php

return [
    'finance.invoice.view',
    'finance.invoice.create',
    'finance.invoice.update',
    'finance.invoice.delete',
    'finance.invoice.publish',
    'finance.invoice.convert_order',
    'finance.receipt.view',
    'finance.receipt.create',
    'finance.receipt.update',
    'finance.receipt.delete',
    'finance.allocation.view',
    'finance.allocation.create',
    'finance.allocation.delete',
    'finance.bank.view',
    'finance.bank.create',
    'finance.bank.update',
    'finance.bank.delete',
    'finance.bank.transaction.create',
    'finance.bank.transaction.delete',
    'finance.report.view',
];

<?php

return [
    'drive.file.view',
    'drive.file.download',
    'drive.file.upload',
    'drive.file.update',
    'drive.file.delete',
    'drive.file.mark',
];

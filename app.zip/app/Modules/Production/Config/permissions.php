<?php

return [
    'production.workorder.view',
    'production.workorder.create',
    'production.workorder.update',
    'production.workorder.delete',
    'production.workorder.close',
];

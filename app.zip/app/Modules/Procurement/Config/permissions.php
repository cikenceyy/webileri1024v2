<?php

return [
    'procurement.purchase_order.view',
    'procurement.purchase_order.create',
    'procurement.purchase_order.update',
    'procurement.purchase_order.delete',
    'procurement.purchase_order.approve',
    'procurement.grn.view',
    'procurement.grn.create',
    'procurement.grn.update',
];

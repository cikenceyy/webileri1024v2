import { bootPage } from '../common/page-boot';

bootPage('kvkk');

<?php

return [
    'settings.company.view',
    'settings.company.update',
    'settings.company.domains.manage',
];

<?php

return [
    'allow_negative_stock' => env('INV_ALLOW_NEGATIVE', false),
    'valuation' => 'wac',
    'default_currency' => 'TRY',
    'default_unit' => 'pcs',
];
